Author: Jason Lin
Class: CS559
Professor Sifakis
Assignment 2

My project is a model of the solar system. I tried to make it as accurate as possible, while still maintaining and being able to see the details and hierarchy for the project. I used the correct shades of colors for most planets and tried to make the size and speed of them relative to each other make sense. The examples of hierarchy in my project include the moon and International Space Station rotating around the Earth, which rotates around the Sun itself. There is also a UFO rotating around Mars and Saturn's rings with a small moon rotating too. I made each planet rotate around the sun indepently from one another so as to make a realistic depiction of some planets. Unfortunately, there are over 200 moons in the system, so I could not draw them all, so I compromised by adding in the Earth's moon, a space station, a UFO, and Saturn's rings for more detail and character.

In this project I utilized the Canvas translate and rotate functions. This project should be able to run in any browser without any libraries installed. I created this in VSCode on a Macbook pro.

Hope you enjoy!
