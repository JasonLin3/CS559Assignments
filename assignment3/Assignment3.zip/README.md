Author: Jason Lin
Class: CS559
Professor Sifakis
Assignment 3

In this project I utilized the glmatrix library for translating and rotating points and shapes based on transformation matrices. I implemented my own stack to hold the transformations and the state of the drawings. This project will run with the gl-matrix-min.js file in it. I created this in VSCode on a Macbook pro.

My project is a model of the solar system. I tried to make it as accurate as possible, while still maintaining and being able to see the details and hierarchy for the project. I used the correct shades of colors for most planets and tried to make the size and speed of them relative to each other make sense. The examples of hierarchy in my project include the moon and International Space Station rotating around the Earth, which rotates around the Sun itself. There is also a UFO rotating around Mars and Saturn's rings with a small moon rotating too. I made each planet rotate around the sun indepently from one another so as to make a realistic depiction of some planets. Unfortunately, there are over 200 moons in the system, so I could not draw them all, so I compromised by adding in the Earth's moon, a space station, a UFO, and Saturn's rings for more detail and character.

Hope you enjoy!
