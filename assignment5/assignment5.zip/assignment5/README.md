Author: Jason Lin
Class: CS559
Professor Sifakis
Assignment 5

This project features a roller coaster park that runs on an infinite loop. The camera circles around the coaster so you can view it from every angle. It uses parametric curves to create a smooth continuous yet winding track that is smooth and continuous throughout. It also draws two parallel paths to resemble the tracks. The scene is actually drawn in 3D, which is apparent as you move the camera and observe it. It utilizes an orthographic transform for viewing.

This project should run with the gl-matrix file. I developed this code on a MacBook Pro. It should run smoothly in the browser.

Hope you enjoy!
